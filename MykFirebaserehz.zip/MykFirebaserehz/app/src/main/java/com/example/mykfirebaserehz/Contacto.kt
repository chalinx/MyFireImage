package com.example.mykfirebaserehz

data class Contacto(
    var nombre: String = "",
    var alias: String = "",
    var idcontacto: Int = 0,
    var key: String = "",
    var codigo: String = "",
    var urlImagen: String = ""
)